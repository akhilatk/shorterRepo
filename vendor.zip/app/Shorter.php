<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Shorter extends Model
{
    //
}
